package ${baseproject}.${project}.${module}.service;

import org.springframework.stereotype.Component;
import ${baseproject}.${project}.common.base.service.BaseService;
import ${baseproject}.${project}.${module}.mapper.${objectname}Mapper;

import javax.annotation.Resource;

@Component("${baseproject}.${project}.${module}.service.${objectname}Service")
public class ${objectname}Service extends BaseService {
    @Resource(name = "${baseproject}.${project}.${module}.mapper.${objectname}Mapper")
    public void setMapper(${objectname}Mapper mapper) {
        super.setMapper(mapper);
    }
}
