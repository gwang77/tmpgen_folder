package ${baseproject}.${project}.${module}.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import ${baseproject}.${project}.common.base.controller.BaseController;
import ${baseproject}.${project}.${module}.service.${objectname}Service;

import javax.annotation.Resource;

@Controller
@RequestMapping("/${objectname.getFirstlowVal()}")
public class ${objectname}Controller extends BaseController {
	@Resource(name = "${baseproject}.${project}.${module}.service.${objectname}Service")
	private ${objectname}Service ${objectname.getFirstlowVal()}Service;

}
