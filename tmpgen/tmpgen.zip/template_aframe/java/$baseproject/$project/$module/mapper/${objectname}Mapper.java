package ${baseproject}.${project}.${module}.mapper;

import org.springframework.stereotype.Component;
import ${baseproject}.${project}.common.base.mapper.BaseMapper;

@Component("${baseproject}.${project}.${module}.mapper.${objectname}Mapper")
public interface ${objectname}Mapper extends BaseMapper {

}
